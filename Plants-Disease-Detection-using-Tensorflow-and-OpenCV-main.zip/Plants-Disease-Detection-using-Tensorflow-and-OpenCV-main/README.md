# Plants-Disease-Detection-using-Tensorflow-and-OpenCV
Implemented Machine Learning and Artificial Intelligence model to detect the different disease on plants using the images.

Use PlantVillage Dataset from kaggle.Link Below

Dataset Link :- https://www.kaggle.com/emmarex/plantdisease

While cloning this repo please use `git-lfs` commands. Quick Link :- https://docs.gitlab.com/ee/topics/git/lfs/

use google colab to train model.

use google drive to mount dataset.

Directory Structure of Dataset should be as follow:- My Drive/Colab Notebook/Plant Village/disease 

/disease--Directory consist of 15 different directories obtained from extracting plant Village Dataset.
